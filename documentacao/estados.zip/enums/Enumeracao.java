package open.digytal.enums;


public interface Enumeracao {
	Object getId();
	String getNome();
}
