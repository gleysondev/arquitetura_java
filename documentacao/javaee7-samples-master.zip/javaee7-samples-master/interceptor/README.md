# Java EE 7 Samples: Interceptor 1.2 #

The [JSR 318](https://jcp.org/en/jsr/detail?id=318) specifies Interceptors 1.2. Since this is a maintenance release on top of 1.1 the JSR number still remained the same as EJB 3.1 (JSR 318). 

## Samples ##

 - around-construct

## How to run

More information on how to run can be found at: <https://github.com/javaee-samples/javaee7-samples#how-to-run->


