package org.javaee7.cdi.events.conditional;

/**
 * @author Radim Hanus
 */
public interface EventReceiver {
	String getGreet();
}
