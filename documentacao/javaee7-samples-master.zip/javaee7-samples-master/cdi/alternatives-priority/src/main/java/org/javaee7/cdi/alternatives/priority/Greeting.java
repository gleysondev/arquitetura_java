package org.javaee7.cdi.alternatives.priority;

/**
 * @author Arun Gupta
 * @author Radim Hanus
 */
public interface Greeting {
    public String greet(String name);
}
