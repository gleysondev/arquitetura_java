package com.gama.repository;

import java.util.List;

import com.gama.model.Carro;

public interface Repositorio {
	public void incluir(Carro contato);
	public void alterar(Carro contato);
	public Carro buscar(Integer id);
	public List<Carro> listar();
}
