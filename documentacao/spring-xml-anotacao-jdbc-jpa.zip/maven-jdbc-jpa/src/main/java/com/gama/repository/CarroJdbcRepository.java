package com.gama.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gama.model.Carro;

public class CarroJdbcRepository implements Repositorio {
	private Connection connecton;
	
	public CarroJdbcRepository() {
		try {
			connecton= DriverManager.getConnection("jdbc:hsqldb:file:/temp/db/sampledb", "SA", "");
		} catch (SQLException ex) {
			ex.printStackTrace();
		} 
	}
	public void incluir(Carro carro) {
		try {
			PreparedStatement st = connecton.prepareStatement("INSERT INTO tab_carro(marca,modelo,cor,capacidade_tanque) values(?,?,?,?)");
			st.setString(1, carro.getMarca());
			st.setString(2, carro.getModelo());
			st.setString(3, carro.getCor());
			st.setInt(4, carro.getCapacidadeTanque());
			int i=st.executeUpdate();  
			System.out.println(i);
			
			st.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void alterar(Carro contato) {
		try {
			PreparedStatement st = connecton.prepareStatement("UPDATE tab_carro set marca=?,modelo=?,cor=?,capacidade_tanque=? WHERE ID = ?");
			st.setString(1, contato.getMarca());
			st.setString(2, contato.getModelo());
			st.setString(3, contato.getCor());
			st.setInt(4, contato.getCapacidadeTanque());
			
			st.setInt(5, contato.getId());
			int i=st.executeUpdate();  
			System.out.println(i);
			
			st.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public Carro buscar(Integer id) {
		String sql = "SELECT marca,modelo,cor,capacidade_tanque,id FROM tab_carro WHERE id = ? ";
		try {
			PreparedStatement st = connecton.prepareStatement(sql);
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			Carro carro=null;
			while(rs.next()){
				carro=converter(rs);
			}
			return carro;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<Carro> listar() {
		String sql = "SELECT marca,modelo,cor,capacidade_tanque,id FROM tab_carro";
		List<Carro> carros=new ArrayList<Carro>();
		try {
			PreparedStatement st = connecton.prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			while(rs.next()){
				Carro carro=converter(rs);
				carros.add(carro);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return carros;
	}
	private Carro converter(ResultSet rs) throws Exception{
		Carro carro=null;
		int codigo = rs.getInt("id");
		String marca = rs.getString("marca");
		String modelo = rs.getString("modelo");
		String cor =  rs.getString("cor");
		int capacidade = rs.getInt("capacidade_tanque");
		
		carro = new Carro();
		carro.setMarca(marca);
		carro.setModelo(modelo);
		carro.setCor(cor);
		carro.setCapacidadeTanque(capacidade);
		carro.setId(codigo);
		
			
		return carro;
	}
	public void fechar() {
		try {
			connecton.close();
			System.exit(0);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
