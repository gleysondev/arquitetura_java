package declaracao.controleacesso.outrasclasses;

public class OutrasClasses {

}
