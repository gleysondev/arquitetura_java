package declaracao.controleacesso.interfaces;

public interface Interface {

}
