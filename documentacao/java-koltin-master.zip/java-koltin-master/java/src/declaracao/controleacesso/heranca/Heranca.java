package declaracao.controleacesso.heranca;

public class Heranca {

}
