package declaracao.controleacesso;

public class Identificadores {

}
