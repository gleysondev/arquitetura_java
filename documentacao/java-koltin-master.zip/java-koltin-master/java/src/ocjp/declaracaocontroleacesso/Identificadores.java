package ocjp.declaracaocontroleacesso;

public class Identificadores {
    public static void main(String[] args) {
        //validos
        int _a;
        int $c;
        int ______2_w;
        int _$;
        int this_is_a_very_detailed_name_for_an_identifier;
        //invalidos
        int :b;
        int -d;
        int e#;
        int .f;
        int 7g;
    }
}
