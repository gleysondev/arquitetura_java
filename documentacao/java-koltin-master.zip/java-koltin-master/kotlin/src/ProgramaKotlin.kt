fun main(args: Array<String>) {
    val numeros=100.downTo(50)
    for(n in numeros){
        println(n)
    }
}


fun receboValorDouble(valor: Double) {
    println("Valore recebido:: " + valor)
}