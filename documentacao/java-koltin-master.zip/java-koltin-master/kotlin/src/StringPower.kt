fun main(args: Array<String>) {
    println("String Power")
}